#Nama/NIM   : Luckman Fakhamanidris Arvasirri/19623053
#Tanggal    : 19 Oktober 2023
#Deskripsi  : Menentukan jumalah potongan list yang jumlahnya prima

#KAMUS
# n, benar, count   :integer
# arr, cek          : array 
#ALGORITMA
#Input
n = int(input("Masukkan nilai N: "))
arr = [int(input(f"Masukkan bilangan ke-{i+1}: ")) for i in range(n)]
benar = 0 #Variabel kosong untuk diisi
count = 1 #Penentu banyaknya langkah yang dilakukan

#Proses
while count <= n: #Menentukan banyaknya pengulangan yang harus dilakukan
    for j in range(n): #Menentukan banyaknhya pengulangan yang dilakukan
        cek = [arr[l] for l in range(count)]
        if (cek + [cek[o] for o in range(count)]) == 2 or (cek + [cek[o] for o in range(count)]) == 3 or (cek + [cek[o] for o in range(count)]) == 5 or (cek + [cek[o] for o in range(count)]) == 7 or (cek + [cek[o] for o in range(count)]) == 11:
            benar +=1
        elif (cek + [cek[o] for o in range(count)])%2 == 0 or (cek + [cek[o] for o in range(count)])%3 == 0 or (cek + [cek[o] for o in range(count)])%7 == 0 or (cek + [cek[o] for o in range(count)])%11 == 0:
            benar += 1 
    count +=1
#Output
print(f"Terdapat {benar} potongan list yang jumlahnya prima")
