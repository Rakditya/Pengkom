#Nama/NIM   : Luckman Fakhamanidris Arvasirri/19623053
#Tanggal    : 19 Oktober 2023
#Deskripsi  : Menentukan apakah tulisan Komi sudah benar

#KAMUS
#n, pkata, panjang, urutan, benar               : integer
#kata, kataakhir, status, katacek, kataakhircek : string

#ALGORITMA
#Input
n = int(input("Masukkan panjang kata asli: "))
kata = input("Masukkan kata asli: ")
pkata = int(input("Masukkan panjang kata yang ditulis: "))
kataakhir = input("Masukkan kata yang ditulis: ")
panjang = n #Menentukan panjang kata yang harus ditulis Komi
urutan = 0 #Variabel kosong untuk diisi
benar = 0 #Variabel kosong untuk diisi
#Proses
for i in range(n):
    panjang += i #total panjang kata yang harus ditulis

if pkata != panjang  or len(kata) != n or len(kataakhir) != panjang: #Menentukan apakah input benar
    benar = 0
else:
    for j in range(1, n+1):
        katacek = [kata[k] for k in range(j)] #Menentukan kata yang harus ditulis pada urutan itu
        kataakhircek = [kataakhir[l] for l in range(urutan, urutan+j)] #Menentukan kata yang ditulis pada urutan itu
        if  katacek == kataakhircek: #Menentukan apakah kata yang ditulis di urutan tersebut benar
            benar +=1
        urutan += j #Menentukan harus mulai mengurut dari  mana

if benar == n: #Menentukan apakah tulisannya sudah benar
    status = 'sudah benar'
else:
    status = 'masih salah'

#Output
print(f"Tulisan Komi {status}")