#Nama/NIM   : Luckman Fakhamanidris Arvasirri/19623053
#Tanggal    : 19 Oktober 2023
#Deskripsi  : Menentukan harga termurah jika makan selama 3 jam berturut-turut

#KAMUS
#n, termurah, hargaakhir: integer
#harga = array

#ALGORITMA
#Input
n = int(input("Masukkan nilai N: "))
harga = [int(input(f"Masukkan harga jam ke-{i+1}: ")) for i in range(n)]
termurah = harga[0] + harga[1] + harga[2]
hargaakhir = 0
#Proses
if n <= 3:
    print("Input error")
else:
    for j in range(n-2):
        hargaakhir += harga[j] + harga[j+1] + harga[j+2]
        if termurah > hargaakhir:
            termurah = hargaakhir
#Output
print(f"Total harga yang harus dibayar adalah {termurah}")